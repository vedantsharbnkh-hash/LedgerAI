/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { 
  Calculator, 
  FileText, 
  Copy, 
  Check, 
  AlertCircle, 
  Loader2, 
  ArrowRight,
  RefreshCw,
  Download,
  Table as TableIcon,
  Code
} from 'lucide-react';
import { Toaster, toast } from 'react-hot-toast';
import { cn } from './lib/utils';
import { AccountingResponse, Transaction } from './types';
import { motion, AnimatePresence } from 'motion/react';

const SYSTEM_INSTRUCTION = `You are an expert Chartered Accountant and specialized OCR-to-Accounting AI. Your objective is to process raw, unstructured, and often messy text extracted from images of handwritten shop diaries, rough ledgers, or informal bills. You must analyze this text, categorize the transactions according to standard double-entry bookkeeping principles, and output the data in a strict, clean JSON format that can be seamlessly imported into accounting software like Tally Prime.

Input Context:
The input text will be OCR-extracted data from local Indian businesses. It may contain:
 * A mix of English, Hindi, and Hinglish (e.g., "Udhaar", "Jama", "Khata", "Cash diya").
 * Incomplete sentences, abbreviations, and informal shorthand.
 * Ambiguous dates or missing contextual information.

Processing Rules & Constraints:
 1. Identify the Transaction: Determine if the text represents a Sale, Purchase, Payment (cash out), Receipt (cash in), Contra (bank/cash transfer), or Journal (adjustments/credit entries).
 2. Determine Voucher Type: Map the transaction strictly to one of the standard Tally Prime Voucher Types: Sales, Purchase, Payment, Receipt, Contra, or Journal.
 3. Ledger Allocation: Identify the primary parties or expense/income heads. Assign clear Debit (Dr.) and Credit (Cr.) ledger names.
   * Example: If text says "Ramesh ko cash diya 500", Debit = "Ramesh A/c", Credit = "Cash A/c".
 4. Amount Extraction: Extract the numeric value. If multiple items are listed, calculate the total transaction amount.
 5. Date Handling: Extract the date if present. If no date is found, output null (do not invent a date).
 6. Narration: Create a concise, professional narration summarizing the rough text (e.g., "Being cash paid to Ramesh").
 7. Error Handling: If the text is completely illegible or not a financial transaction, return an empty array [] and flag an error in the "status" field.`;

export default function App() {
  const [inputText, setInputText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<AccountingResponse | null>(null);
  const [viewMode, setViewMode] = useState<'table' | 'json'>('table');
  const [copied, setCopied] = useState(false);

  const processOCR = async () => {
    if (!inputText.trim()) {
      toast.error('Please provide some OCR text to process.');
      return;
    }

    setIsProcessing(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3.1-pro-preview",
        contents: inputText,
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              status: { type: Type.STRING, enum: ["success", "error"] },
              error_message: { type: Type.STRING, nullable: true },
              transactions: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    date: { type: Type.STRING, nullable: true },
                    voucher_type: { type: Type.STRING, enum: ["Payment", "Receipt", "Sales", "Purchase", "Contra", "Journal"] },
                    debit_ledger: { type: Type.STRING },
                    credit_ledger: { type: Type.STRING },
                    amount: { type: Type.NUMBER },
                    narration: { type: Type.STRING },
                    original_rough_text: { type: Type.STRING }
                  },
                  required: ["voucher_type", "debit_ledger", "credit_ledger", "amount", "narration", "original_rough_text"]
                }
              }
            },
            required: ["status", "transactions"]
          }
        }
      });

      const parsedResult = JSON.parse(response.text || '{}') as AccountingResponse;
      
      if (parsedResult.status === 'error') {
        toast.error(parsedResult.error_message || 'Failed to process transactions');
      } else {
        setResult(parsedResult);
        toast.success(`Successfully processed ${parsedResult.transactions.length} transactions`);
      }
    } catch (error) {
      console.error('Error processing OCR:', error);
      toast.error('An error occurred while connecting to the AI service.');
    } finally {
      setIsProcessing(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    toast.success('Copied to clipboard');
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadJSON = () => {
    if (!result) return;
    const blob = new Blob([JSON.stringify(result, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ledger_export_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-[#E4E3E0] text-[#141414] font-sans selection:bg-[#141414] selection:text-[#E4E3E0]">
      <Toaster position="top-right" />
      
      {/* Header */}
      <header className="border-b border-[#141414] p-6 md:p-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="bg-[#141414] p-2 rounded-sm">
                <Calculator className="text-[#E4E3E0] w-6 h-6" />
              </div>
              <h1 className="text-3xl md:text-4xl font-bold tracking-tighter uppercase italic font-serif">
                LedgerAI
              </h1>
            </div>
            <p className="text-sm font-mono opacity-60 uppercase tracking-widest">
              Expert OCR-to-Accounting AI • Chartered Accountant Edition
            </p>
          </div>
          <div className="flex items-center gap-4 text-xs font-mono opacity-40">
            <span>V1.0.4</span>
            <span className="w-1 h-1 bg-[#141414] rounded-full"></span>
            <span>TALLY PRIME COMPATIBLE</span>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-6 md:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Input Section */}
        <section className="lg:col-span-5 flex flex-col gap-6">
          <div className="flex items-center justify-between">
            <h2 className="font-serif italic text-sm uppercase tracking-widest opacity-50">
              Raw OCR Input
            </h2>
            <button 
              onClick={() => setInputText('')}
              className="text-[10px] font-mono uppercase tracking-tighter hover:underline opacity-40 hover:opacity-100 transition-opacity"
            >
              Clear Input
            </button>
          </div>
          
          <div className="relative group">
            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Paste raw OCR text here... (e.g., '12 Oct. Ramu chai wale ko 150 rs diye...')"
              className="w-full h-[400px] bg-transparent border border-[#141414] p-4 font-mono text-sm focus:outline-none focus:ring-1 focus:ring-[#141414] resize-none transition-all placeholder:opacity-30"
            />
            <div className="absolute bottom-4 right-4 flex items-center gap-2">
              <button
                onClick={() => setInputText("12 Oct. Ramu chai wale ko 150 rs diye. Aur light bill ka 1200 bhara cash.\nManoj Traders se 5000 ka maal udhar aaya.")}
                className="px-3 py-3 border border-[#141414] font-mono text-[10px] uppercase tracking-widest hover:bg-[#141414] hover:text-[#E4E3E0] transition-all"
              >
                Sample
              </button>
              <button
                onClick={processOCR}
                disabled={isProcessing || !inputText.trim()}
                className={cn(
                  "flex items-center gap-2 px-6 py-3 bg-[#141414] text-[#E4E3E0] font-mono text-xs uppercase tracking-widest transition-all",
                  (isProcessing || !inputText.trim()) ? "opacity-50 cursor-not-allowed" : "hover:bg-opacity-90 active:scale-95"
                )}
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    Process
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="p-4 border border-[#141414] border-dashed opacity-40">
            <h3 className="text-[10px] font-mono uppercase tracking-widest mb-2 font-bold">Quick Tips:</h3>
            <ul className="text-[10px] font-mono space-y-1">
              <li>• Supports Hindi, English, and Hinglish</li>
              <li>• Automatically identifies Voucher Types</li>
              <li>• Handles multiple transactions in one block</li>
              <li>• Extracts dates and amounts with high precision</li>
            </ul>
          </div>
        </section>

        {/* Results Section */}
        <section className="lg:col-span-7 flex flex-col gap-6">
          <div className="flex items-center justify-between">
            <h2 className="font-serif italic text-sm uppercase tracking-widest opacity-50">
              Accounting Output
            </h2>
            {result && (
              <div className="flex items-center gap-2 bg-[#141414] bg-opacity-5 p-1 rounded-sm">
                <button
                  onClick={() => setViewMode('table')}
                  className={cn(
                    "p-1.5 rounded-sm transition-all",
                    viewMode === 'table' ? "bg-[#141414] text-[#E4E3E0]" : "text-[#141414] opacity-40 hover:opacity-100"
                  )}
                >
                  <TableIcon className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setViewMode('json')}
                  className={cn(
                    "p-1.5 rounded-sm transition-all",
                    viewMode === 'json' ? "bg-[#141414] text-[#E4E3E0]" : "text-[#141414] opacity-40 hover:opacity-100"
                  )}
                >
                  <Code className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>

          <div className="min-h-[400px] border border-[#141414] relative overflow-hidden">
            <AnimatePresence mode="wait">
              {!result && !isProcessing && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center opacity-20"
                >
                  <FileText className="w-12 h-12 mb-4" />
                  <p className="font-mono text-xs uppercase tracking-widest">
                    Awaiting input processing...
                  </p>
                </motion.div>
              )}

              {isProcessing && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center"
                >
                  <RefreshCw className="w-10 h-10 mb-4 animate-spin opacity-20" />
                  <p className="font-mono text-xs uppercase tracking-widest opacity-40 animate-pulse">
                    Analyzing ledgers & vouchers...
                  </p>
                </motion.div>
              )}

              {result && !isProcessing && (
                <motion.div 
                  key={viewMode}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="h-full overflow-auto"
                >
                  {viewMode === 'table' ? (
                    <div className="p-0">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="border-bottom border-[#141414] bg-[#141414] text-[#E4E3E0]">
                            <th className="p-3 font-serif italic text-[10px] uppercase tracking-widest font-normal">Date</th>
                            <th className="p-3 font-serif italic text-[10px] uppercase tracking-widest font-normal">Voucher</th>
                            <th className="p-3 font-serif italic text-[10px] uppercase tracking-widest font-normal">Ledgers (Dr/Cr)</th>
                            <th className="p-3 font-serif italic text-[10px] uppercase tracking-widest font-normal text-right">Amount</th>
                          </tr>
                        </thead>
                        <tbody className="font-mono text-[11px]">
                          {result.transactions.map((tx, idx) => (
                            <tr key={idx} className="border-b border-[#141414] border-opacity-10 hover:bg-[#141414] hover:text-[#E4E3E0] transition-colors group">
                              <td className="p-3 align-top opacity-60 group-hover:opacity-100">{tx.date || '---'}</td>
                              <td className="p-3 align-top">
                                <span className={cn(
                                  "px-1.5 py-0.5 rounded-sm text-[9px] font-bold uppercase",
                                  tx.voucher_type === 'Payment' && "bg-red-100 text-red-800",
                                  tx.voucher_type === 'Receipt' && "bg-green-100 text-green-800",
                                  tx.voucher_type === 'Sales' && "bg-blue-100 text-blue-800",
                                  tx.voucher_type === 'Purchase' && "bg-orange-100 text-orange-800",
                                  "group-hover:bg-transparent group-hover:text-inherit group-hover:border group-hover:border-current"
                                )}>
                                  {tx.voucher_type}
                                </span>
                              </td>
                              <td className="p-3">
                                <div className="font-bold">Dr. {tx.debit_ledger}</div>
                                <div className="opacity-60 group-hover:opacity-100">Cr. {tx.credit_ledger}</div>
                                <div className="mt-2 text-[9px] italic opacity-40 group-hover:opacity-80 max-w-[200px]">
                                  {tx.narration}
                                </div>
                              </td>
                              <td className="p-3 text-right font-bold align-top">
                                ₹{tx.amount.toLocaleString('en-IN')}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="p-4 h-full bg-[#141414] text-[#E4E3E0] font-mono text-[11px] overflow-auto">
                      <div className="flex justify-between items-center mb-4 border-b border-[#E4E3E0] border-opacity-20 pb-2">
                        <span className="opacity-50 uppercase tracking-widest">Raw JSON Data</span>
                        <div className="flex gap-2">
                          <button 
                            onClick={() => copyToClipboard(JSON.stringify(result, null, 2))}
                            className="hover:text-white transition-colors flex items-center gap-1"
                          >
                            {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                            COPY
                          </button>
                          <button 
                            onClick={downloadJSON}
                            className="hover:text-white transition-colors flex items-center gap-1"
                          >
                            <Download className="w-3 h-3" />
                            SAVE
                          </button>
                        </div>
                      </div>
                      <pre className="whitespace-pre-wrap">
                        {JSON.stringify(result, null, 2)}
                      </pre>
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {result && (
            <div className="flex items-center justify-between p-4 border border-[#141414] bg-[#141414] text-[#E4E3E0]">
              <div className="flex items-center gap-4">
                <div className="flex flex-col">
                  <span className="text-[9px] font-mono uppercase opacity-50">Total Transactions</span>
                  <span className="font-serif italic text-lg">{result.transactions.length}</span>
                </div>
                <div className="w-px h-8 bg-[#E4E3E0] opacity-20"></div>
                <div className="flex flex-col">
                  <span className="text-[9px] font-mono uppercase opacity-50">Total Value</span>
                  <span className="font-serif italic text-lg">
                    ₹{result.transactions.reduce((sum, tx) => sum + tx.amount, 0).toLocaleString('en-IN')}
                  </span>
                </div>
              </div>
              <button 
                onClick={downloadJSON}
                className="flex items-center gap-2 px-4 py-2 border border-[#E4E3E0] hover:bg-[#E4E3E0] hover:text-[#141414] transition-all font-mono text-[10px] uppercase tracking-widest"
              >
                Export for Tally
                <Download className="w-3 h-3" />
              </button>
            </div>
          )}
        </section>
      </main>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto p-6 md:p-8 mt-auto border-t border-[#141414] border-opacity-10">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 opacity-40 text-[10px] font-mono uppercase tracking-widest">
          <p>© 2026 LedgerAI Systems • Confidential & Secure</p>
          <div className="flex gap-6">
            <a href="#" className="hover:underline">Privacy Policy</a>
            <a href="#" className="hover:underline">Terms of Service</a>
            <a href="#" className="hover:underline">API Documentation</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
